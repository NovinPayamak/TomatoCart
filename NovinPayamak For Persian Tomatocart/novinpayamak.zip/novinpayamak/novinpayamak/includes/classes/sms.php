<?php
/*
  $Id: sms.php $
  $module: novinpayamak Persian TomatoCart Module $
  $author: Ali Masooumi $
*/
  require_once(realpath(dirname(__FILE__) . '/../../') . '/ext/lib/nusoap.php');

  class osC_Sms {
    var $_to,
        $_body,
        $_username = SMS_GETWAY_USERNAME,
        $_password = SMS_GETWAY_PASSWORD,
        $_from = SMS_GETWAY_FROM_NUMBER,
        $_flash = false;

    function osC_Sms($to_mobile_number = null,$sms_text) {
      if ( !empty($to_mobile_number) ) {
        $this->_to = $to_mobile_number;
      }
        $this->_body = $sms_text;
    }

    function send() {

     if (SMS_GATEWAY == 'NovinPayamak') {
	 
        return $this->sendNovinPayamak();
		
      } 
      
      return false;
    }
	
    function sendNovinPayamak() 
	{
		$client =  new nusoap_client('http://www.novinpayamak.com/services/SMSBox/wsdl', 'wsdl'); 
		$client->soap_defencoding = 'UTF-8';

		$res = $client->call('Send', array(
			array(
					'Auth' 	=> array('number' => $this->_from, 'pass' => $this->_password),
					'Recipients' 		=> array($this->_to),
					'Message' 	=> array($this->_body),
					'Flash' 		=> $this->_flash
				)
		));
		
		return $res['Status'];
	}
	
  }
?>
